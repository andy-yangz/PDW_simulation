
function h = get_h(q)

parameter;

h = zeros(3,1);
h(1,1) = -a*q(6)^2*m1*sin(q(3));
h(2,1) = m1*(g-a*q(6)^2*cos(q(3)));
h(3,1) = -a*g*m1*sin(q(3));

end